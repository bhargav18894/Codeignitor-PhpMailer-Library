<?php
header('Access-Control-Allow-Origin: *');
	class Index extends CI_Controller {
		function __construct() {
			parent::__construct();
			$this->load->library('session');
			$this->load->helper('Commoncontroller');
		}
	function view ($page = 'home'){
		$data = common();
		if(! file_exists('application/views/index/'.$page.'.php')){
			show_404();
		}	 
		$data['title']='PXLSoft';
		$this->load->view('tamplates/header',$data);
		$this->load->view('index/'.$page,$data);
		$this->load->view('tamplates/footer');
	}
	function TrialDownload (){
		$this->load->model('Trial');
		$this->load->library('form_validation');
		$this->form_validation->set_error_delimiters('', '');
		$this->form_validation->set_rules('consumer_name', 'Username', 'required');
		$this->form_validation->set_rules('email', 'Email', 'required|valid_email');
		$this->form_validation->set_rules('contact_number', 'Phone Number', 'required|numeric');
		$this->form_validation->set_rules('country_id', 'Country Name', 'required');
		$captcha_sess = $this->input->post('captchaCode');
		$captcha_post = $this->input->post('captcha');
		if($captcha_sess != $captcha_post){
			$res['message'] = 'Wrong captcha code..!!';
			$res['code'] = '200';
		}else{
			if ($this->form_validation->run() == FALSE) {			
			$res['message'] = validation_errors();
			$res['code'] = '200';
				
			} else {			
				$data = array(
					'consumer_name' => $this->input->post('consumer_name'),
					'email' => $this->input->post('email'),
					'contact_number' => $this->input->post('contact_number'),
					'country_id' => $this->input->post('country_id'),
					'download_for' => $this->input->post('download_for')
				);			
				$this->Trial->form_insert($data);
				$res['message'] = 'Data Inserted Successfully';
				$res['code'] = '100';
			}
		}
		
		echo json_encode($res);
		exit();
	}
	 function send_mail($destino,$message,$subject) {
			$ci =& get_instance();
			$ci->load->library('My_PHPMailer');
	        $mail = new PHPMailer();
	        $mail->IsSMTP(); // we are going to use SMTP
	        $mail->SMTPOptions = array(
			    'ssl' => array(
			        'verify_peer' => false,
			        'verify_peer_name' => false,
			        'allow_self_signed' => true
			    )
			);
	        $mail->SMTPAuth   = true;
	        //$mail->SMTPDebug = 2; 
	        $mail->SMTPSecure = "tls";	      	        
			$mail->Host       = "smtp.gmail.com";      
	        $mail->Port       = 587;                 
	        $mail->Username   = "support.pxlsoft@imageinkindia.com";  
	        $mail->Password   = "Pxlsoft@123";
			$mail->SetFrom($mail->Username, 'PXLSoft-Team');
	        $mail->IsHTML(true);  
	        $mail->Subject    = $subject;
	        $mail->Body      = $message;
	        $mail->AddAddress($destino);
	        if(!$mail->Send()) {
	            $data["message"] = "Error: " . $mail->ErrorInfo;
	        } else {
	            $data["message"] = "Message sent correctly!";
	        }
        return $data;
    }
	function contactus (){
		$this->load->helper('url');
		$this->load->library('session');
		$this->load->model('Contactus');
		$this->load->library('form_validation');
		$this->form_validation->set_error_delimiters('', '');
		$this->form_validation->set_rules('customer_name', 'Name', 'required');
		$this->form_validation->set_rules('email', 'Email', 'required|valid_email');
		$this->form_validation->set_rules('contact_number', 'Phone Number', 'required|numeric');
		$this->form_validation->set_rules('country_id', 'Country Name', 'required');
		$this->form_validation->set_rules('message', 'Message', 'required');
		if ($this->form_validation->run() == FALSE) {	
			$this->session->set_flashdata('Contactus_msg', validation_errors());
			$in=validation_errors();
			redirect(base_url()."index.php/contactus".$in);
		} else {	

			$this->session->set_flashdata('Contactus_msg', 'Your Request Send Successfully');
			$data = array(
				'customer_name' => $this->input->post('customer_name'),
				'email' => $this->input->post('email'),
				'contact_number' => $this->input->post('contact_number'),
				'country_id' => $this->input->post('country_id'),
				'studio_name' => $this->input->post('studio_name'),
				'mail_for' => $this->input->post('Enquiry'),
				'message' => $this->input->post('message')
			);			
			 $this->Contactus->form_insert($data);

			//$destino='support@pxlsoft.com';	
			$destino='disha@parextech.com';			
			if($this->input->post('Enquiry')=='Technical_Support'){
				$subject='Contact for Technical Support';
			}else{
				$subject='Contact for Sales Enquiry';
			}
			$message='Enquiry From : '.$this->input->post('customer_name').'<br>Email : '.$this->input->post('email').'<br> Contact Number : '.$this->input->post('contact_number').' <br>Enquiry : '. $this->input->post('message').'';
			$data = send_mail($destino,$message,$subject);
			$cus_msg='Dear '.$this->input->post('customer_name').',<br/><br/>Greetings from PXLSoft !!! We are glad to be of service to you.<br/><br/>We have received your query. We shall response to your query as soon as we can.<br/><br/>Alternately, you could also speak to one of the Support Executives on our USA telephone line +1 732 947 4511 / Worldwide telephone line +91 22 6232 2943. Our Support Centers are open from 10.00am to 7.00 pm PM IST Monday to Friday.<br/><br/>Thanks & Regards,<br/>PXLSoft.<br/>';
			$data1 = send_mail($this->input->post('email'),$cus_msg,$subject);

			redirect(base_url()."index.php/contactus/");		
		}		
	}
	function popupCookie(){
		 $this->load->helper('cookie');

         $cookie = array(
           'name'   => 'popup_delete',
           'value'  => '1',
           'expire' => '3600',
           'prefix' => ''
        );
        $this->input->set_cookie($cookie);
		exit;
	}
	function refresh_captcha(){
		$this->load->helper(array('url','captcha'));
		$vals = array(
		        //'word'          => 'Random word',
	        'img_path'      => APPPATH.'../images/captcha/',
	        'img_url'       => base_url('images/captcha/'),
	        'font_path'     => base_url() .'/fonts/texb.ttf',
	        'img_width'     => '150',
	        'img_height'    => 30,
	        'expiration'    => 7200,
	        'word_length'   => 6,
	        'font_size'     => 16,
	        'img_id'        => 'Imageid',
	        'pool'          => 'ABCDEFGHIJKLMNOPQRSTUVWXYZ',

	        // White background and border, black text and red grid
	        'colors'        => array(
	                'background' => array(255, 255, 255),
	                'border' => array(255, 255, 255),
	                'text' => array(0, 0, 0),
	                'grid' => array(255, 40, 40)
	        )
		);

		$cap = create_captcha($vals);
		$msg['data']=$cap['image'];
		$msg['captchaCode']=$cap['word'];
		echo json_encode($msg);
		exit();
	}
}